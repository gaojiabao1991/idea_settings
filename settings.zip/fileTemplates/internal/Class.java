#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * Created by jiabao.gao on ${YEAR}-${MONTH}-${DAY}.
 */
public class ${NAME} {
}
